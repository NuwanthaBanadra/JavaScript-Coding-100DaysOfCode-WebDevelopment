body {
    font-family: Arial, sans-serif;
    text - align: center;
    margin: 0;
    padding: 0;
    height: 100vh;
    display: flex;
    justify - content: center;
    align - items: center;
    background - color: #f4f4f4;
    transition: background - color 0.5s ease;
}

.container {
    text-align: center;
}

button {
    font-size: 18px;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    background - color: #007bff;
    color: white;
    border - radius: 5px;
    transition: background 0.3s ease;
}

button: hover {
    background - color: #0056b3;
}