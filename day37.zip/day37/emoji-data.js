const emojiList = [
    { emoji: "😀", name: "grinning" },
    { emoji: "😂", name: "joy" },
    { emoji: "😍", name: "heart eyes" },
    { emoji: "😎", name: "cool" },
    { emoji: "😭", name: "cry" },
    { emoji: "👍", name: "thumbs up" },
    { emoji: "🔥", name: "fire" },
    { emoji: "💯", name: "100" },
    { emoji: "🎉", name: "celebration" },
    { emoji: "🚀", name: "rocket" },
];
